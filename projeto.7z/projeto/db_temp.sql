-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23-Jun-2022 às 03:33
-- Versão do servidor: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_temp`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `controle`
--

CREATE TABLE `controle` (
  `id` int(11) NOT NULL,
  `atualizacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `umidade` float NOT NULL,
  `temperatura` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `controle`
--

INSERT INTO `controle` (`id`, `atualizacao`, `umidade`, `temperatura`) VALUES
(1, '2022-06-22 20:20:20', 20, 10),
(2, '2022-06-22 20:21:47', 15, 25),
(3, '2022-06-22 20:23:11', 15, 30),
(4, '2022-06-22 20:30:43', 25, 30);

-- --------------------------------------------------------

--
-- Stand-in structure for view `telemetria`
--
CREATE TABLE `telemetria` (
`Umidade_Media` double
,`Temperatura_Media` double
,`Temperatura_Maxima` float
,`Umidade_Maxima` float
,`Umidade_Minima` float
,`temperatura_Minima` float
);

-- --------------------------------------------------------

--
-- Structure for view `telemetria`
--
DROP TABLE IF EXISTS `telemetria`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `telemetria`  AS  select avg(`controle`.`umidade`) AS `Umidade_Media`,avg(`controle`.`temperatura`) AS `Temperatura_Media`,max(`controle`.`temperatura`) AS `Temperatura_Maxima`,max(`controle`.`umidade`) AS `Umidade_Maxima`,min(`controle`.`umidade`) AS `Umidade_Minima`,min(`controle`.`temperatura`) AS `temperatura_Minima` from `controle` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `controle`
--
ALTER TABLE `controle`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `controle`
--
ALTER TABLE `controle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

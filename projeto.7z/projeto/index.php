<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Telemetria</title>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <div class="row row-cols-2 row-cols-md-1 mb-3 text-center">
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-body">
            <table class="table table-hover">

            <thead>
            <tr>
                <center><h1>Informações de Telemetria</h1></center>
                <th scope="col">Umidade Média</th>
                <th scope="col">Temperatura Média</th>
                <th scope="col">Umidade Maxima</th>
                <th scope="col">Temperatura Maxima</th>
                <th scope="col">Umidade Mimina</th>
                <th scope="col">Temperatura Minima</th>
            </tr>
            </thead>
            <tbody>
            <?php
            include 'conecta.php';
            $pesquisa = mysqli_query($conn, "SELECT * FROM telemetria");
            $row = mysqli_num_rows($pesquisa);
            if($row > 0){
                while($registro = $pesquisa-> fetch_array()){
                    echo '<tr>';
                    echo '<td>'.$registro['Umidade_Media'].'</td>';
                    echo '<td>'.$registro['Temperatura_Media'].'</td>';
                    echo '<td>'.$registro['Umidade_Maxima'].'</td>';
                    echo '<td>'.$registro['Temperatura_Maxima'].'</td>';
                    echo '<td>'.$registro['Umidade_Minima'].'</td>';
                    echo '<td>'.$registro['temperatura_Minima'].'</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            }
            else {
                echo "Não há registros inseridos!!!";
                echo '</tbody>';
                echo '</table>';
            }
            ?>
           </tbody>
           
          </div>
        </div>
      </div>
    </div>

    <div class="row row-cols-2 row-cols-md-1 mb-3 text-center">
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-body">
            <table class="table table-hover">
            
            <form action="index.php" method="POST">
              <input type="date">
              <button type="submit">Pesquisar Dia</button>
            </form>

            <thead>
            <tr>
                <center><h1>Informações Pesquisa do dia</h1></center>
                <th scope="col">Umidade Média</th>
                <th scope="col">Temperatura Média</th>
                <th scope="col">Umidade Maxima</th>
                <th scope="col">Temperatura Maxima</th>
                <th scope="col">Umidade Mimina</th>
                <th scope="col">Temperatura Minima</th>
            </tr>
            </thead>
            <tbody>
            <?php
            include 'conecta.php';
            $pesquisa = mysqli_query($conn, "SELECT AVG(controle.umidade) Umidade_Media, AVG(contole.Temperatura) Temperatura_Media MAX(controle.umidade) Umidade_Maxima, MAX(controle.temperatura) Temperatura_Maxima, MIN(contole.umidade) Umidade_Minima, MIN(contole.temperatura) temperatura_Minima FROM telemetria WHERE controle.atualizacao=$data");
            $row = mysqli_num_rows($pesquisa);
            if($row > 0){
                while($registro = $pesquisa-> fetch_array()){
                    echo '<tr>';
                    echo '<td>'.$registro['Umidade_Media'].'</td>';
                    echo '<td>'.$registro['Temperatura_Media'].'</td>';
                    echo '<td>'.$registro['Umidade_Maxima'].'</td>';
                    echo '<td>'.$registro['Temperatura_Maxima'].'</td>';
                    echo '<td>'.$registro['Umidade_Minima'].'</td>';
                    echo '<td>'.$registro['temperatura_Minima'].'</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            }
            else {
                echo "Não há registros inseridos!!!";
                echo '</tbody>';
                echo '</table>';
            }
            ?>
           </tbody>
           
          </div>
        </div>
      </div>
    </div>



</body>
</html>
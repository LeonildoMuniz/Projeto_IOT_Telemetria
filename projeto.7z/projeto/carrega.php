
<?php
    include 'conecta.php';
    $umidade = $_GET['umidade'];
    $temperatura = $_GET['temperatura'];



    $sql = "INSERT INTO controle(temperatura, umidade) VALUES('$temperatura','$umidade')";
    if(mysqli_query($conn,$sql))
    {
        echo "<script language='javascript' type='text/javascript'>
        alert('Registro inserido com sucesso!');
        </script>";
    }
    else{
        echo "<script language='javascript' type='text/javascript'>
        alert('Registro não foi inserido!');
        </script>";        
    }
    mysqli_close($conn);
?>